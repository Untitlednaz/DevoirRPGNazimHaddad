import java.util.Scanner;

public class RPGGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        WeaponStore store = new WeaponStore();
        int playerGold = 100;  // Le joueur commence avec 100 pièces d'or

        System.out.println("Bienvenue dans votre aventure RPG !");
        System.out.println("Vous avez " + playerGold + " pièces d'or.");
        boolean running = true;

        while (running) {
            System.out.println("\nQue voulez-vous faire ?");
            System.out.println("1. Voir le magasin d'armes");
            System.out.println("2. Quitter le jeu");
            System.out.print("Votre choix : ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    store.displayWeapons();
                    System.out.print("\nEntrez le numéro de l'arme que vous voulez acheter (ou 0 pour annuler) : ");
                    int weaponChoice = scanner.nextInt();
                    if (weaponChoice == 0) {
                        System.out.println("Retour au menu principal.");
                    } else {
                        store.buyWeapon(weaponChoice, playerGold);
                    }
                    break;

                case 2:
                    System.out.println("Merci d'avoir joué ! À bientôt !");
                    running = false;
                    break;

                default:
                    System.out.println("Choix invalide !");
            }
        }

        scanner.close();
    }
}