import java.util.ArrayList;

public class WeaponStore {
    private ArrayList<Weapon> weapons;  // Liste des armes disponibles dans le magasin

    // Constructeur
    public WeaponStore() {
        weapons = new ArrayList<>();
        weapons.add(new Axe());
        weapons.add(new Hammer());
        weapons.add(new Bow());
    }

    // Méthode pour afficher les armes disponibles
    public void displayWeapons() {
        System.out.println("Bienvenue dans le magasin d'armes !");
        System.out.println("Voici les armes disponibles :");
        for (int i = 0; i < weapons.size(); i++) {
            System.out.print((i + 1) + ". ");
            weapons.get(i).displayInfo();
        }
    }

    // Méthode pour acheter une arme
    public void buyWeapon(int choice, int playerGold) {
        if (choice < 1 || choice > weapons.size()) {
            System.out.println("Choix invalide !");
            return;
        }

        Weapon selectedWeapon = weapons.get(choice - 1);
        if (playerGold >= selectedWeapon.getPrice()) {
            System.out.println("Vous avez acheté : " + selectedWeapon.getName());
        } else {
            System.out.println("Vous n'avez pas assez d'or pour acheter cette arme !");
        }
    }
}