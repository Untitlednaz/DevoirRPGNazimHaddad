public class Weapon {
    private String name;  // Nom de l'arme
    private int damage;   // Dégâts infligés par l'arme
    private int price;    // Prix de l'arme

    // Constructeur
    public Weapon(String name, int damage, int price) {
        this.name = name;
        this.damage = damage;
        this.price = price;
    }

    // Méthode pour afficher les informations de l'arme
    public void displayInfo() {
        System.out.println("Nom : " + name + ", Dégâts : " + damage + ", Prix : " + price + " pièces d'or");
    }

    // Getter pour le prix
    public int getPrice() {
        return price;
    }

    // Getter pour le nom
    public String getName() {
        return name;
    }
}