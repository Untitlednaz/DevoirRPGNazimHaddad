public class Axe extends Weapon {
    public Axe() {
        super("Hache", 15, 50);  // Nom : Hache, Dégâts : 15, Prix : 50
    }
}