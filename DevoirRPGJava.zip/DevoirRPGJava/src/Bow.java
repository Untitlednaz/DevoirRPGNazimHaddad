public class Bow extends Weapon {
    public Bow() {
        super("Arc", 10, 40);  // Nom : Arc, Dégâts : 10, Prix : 40
    }
}