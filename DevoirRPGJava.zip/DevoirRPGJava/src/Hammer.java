public class Hammer extends Weapon {
    public Hammer() {
        super("Marteau", 20, 70);  // Nom : Marteau, Dégâts : 20, Prix : 70
    }
}